// --- UTILITY ---
function debounce(fn, delay) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
}

// --- STATE ---
const state = {
  activeTheme: 'light',
  isFocusMode: false,
  savedRange: null,
  activeSnippetIndex: 0,
  filteredSnippets: [],
  filePath: null,
  isDirty: false,
  autosaveTimer: null,
  settings: {
    editorFont: 'serif',
    fontSize: 18,
    autosaveEnabled: true
  }
};

// --- TAB STATE ---
let nextTabId = 2;
const tabs = [];
let activeTabId = 1;

// --- SNIPPET CATALOG ---
const snippetCatalog = [
  {
    name: 'JavaScript - Hello Developer',
    desc: 'Prints a console message welcoming the user.',
    lang: 'javascript',
    tags: ['js', 'javascript', 'log', 'function', 'hello'],
    code: `// Elegant greetings for pair programming
function welcomeAgent() {
  const agentName = "Antigravity";
  const year = new Date().getFullYear();
  console.log(\`[\${year}] Welcome to a new dimension of pair programming with \${agentName}!\`);
}

welcomeAgent();`
  },
  {
    name: 'JavaScript - Async Fetch API',
    desc: 'Standard async/await API request template with error handling.',
    lang: 'javascript',
    tags: ['js', 'javascript', 'async', 'await', 'fetch', 'api', 'http'],
    code: `// Fetch data asynchronously from a REST endpoint
async function fetchData(url = '/api/documents') {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(\`Network response was not OK: \${response.status}\`);
    }
    const data = await response.json();
    console.log("Successfully fetched payload:", data);
    return data;
  } catch (error) {
    console.error("Fetch transaction failed:", error);
  }
}`
  },
  {
    name: 'Python - Quick Sort Algorithm',
    desc: 'Clean, idiomatic implementation of Python Quick Sort.',
    lang: 'python',
    tags: ['py', 'python', 'sort', 'algorithm', 'recursion'],
    code: `# In-place recursion sorting algorithm
def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)

numbers = [3, 6, 8, 10, 1, 2, 1]
print("Original Array:", numbers)
print("Sorted Array:", quick_sort(numbers))`
  },
  {
    name: 'Python - Read Local File',
    desc: 'Safely open and parse file resources using a context manager.',
    lang: 'python',
    tags: ['py', 'python', 'file', 'read', 'with', 'open'],
    code: `# Safe resource extraction using context managers
def extract_document_contents(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as target_file:
            content = target_file.read()
            print(f"Read {len(content)} characters successfully.")
            return content
    except FileNotFoundError:
        print(f"Error: The resource at '{filepath}' was not found.")
        return None`
  },
  {
    name: 'CSS - Flexbox Centering Grid',
    desc: 'Perfect vertical and horizontal centering layout toolkit.',
    lang: 'css',
    tags: ['css', 'style', 'layout', 'flex', 'center', 'align'],
    code: `/* Ultimate Flexbox layout alignment system */
.centering-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  padding: 2rem;
  background: radial-gradient(circle at center, #ffffff 0%, #f1f5f9 100%);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}`
  },
  {
    name: 'CSS - Responsive Media Query',
    desc: 'Standard breakpoints for highly responsive mobile viewport layouts.',
    lang: 'css',
    tags: ['css', 'style', 'responsive', 'media', 'mobile', 'query'],
    code: `/* Standard mobile and handheld responsiveness blueprint */
@media screen and (max-width: 768px) {
  .editor-workspace {
    padding: 1rem 0 !important;
  }

  .paper {
    padding: 1.5rem !important;
    border-radius: 0 !important;
    box-shadow: none !important;
  }

  .app-header {
    flex-direction: column;
    align-items: stretch;
  }
}`
  },
  {
    name: 'SQL - Aggregation & Query',
    desc: 'Selects average revenue grouped and sorted with conditions.',
    lang: 'sql',
    tags: ['sql', 'query', 'database', 'aggregate', 'group', 'join'],
    code: `-- Aggregate and sort data with sub-categorizations
SELECT
    d.department_name,
    COUNT(e.employee_id) AS total_staff,
    ROUND(AVG(e.salary), 2) AS average_salary
FROM employees e
INNER JOIN departments d ON e.department_id = d.department_id
WHERE e.hire_date >= '2025-01-01'
GROUP BY d.department_name
HAVING AVG(e.salary) > 65000
ORDER BY average_salary DESC;`
  },
  {
    name: 'C++ - Hello World & Struct',
    desc: 'Starter template containing Standard I/O and object blueprint.',
    lang: 'cpp',
    tags: ['cpp', 'c++', 'hello', 'class', 'struct', 'main'],
    code: `#include <iostream>
#include <string>
#include <vector>

struct Document {
    std::string title;
    int wordCount;
};

int main() {
    Document doc = {"frank Release", 450};
    std::cout << "Project: " << doc.title << "\\n";
    std::cout << "Loaded Words: " << doc.wordCount << "\\n";
    return 0;
}`
  },
  {
    name: 'R - Data Wrangling with dplyr',
    desc: 'Filter, group, and summarise a data frame using tidyverse verbs.',
    lang: 'r',
    tags: ['r', 'dplyr', 'tidyverse', 'data', 'wrangling', 'pipe'],
    code: `library(dplyr)

# Load built-in dataset
data(mtcars)
mtcars <- as_tibble(mtcars, rownames = "model")

# Tidy pipeline: filter → group → summarise → arrange
result <- mtcars |>
  filter(cyl %in% c(4, 6)) |>
  group_by(cyl) |>
  summarise(
    n          = n(),
    mean_mpg   = round(mean(mpg), 2),
    median_hp  = median(hp),
    .groups    = "drop"
  ) |>
  arrange(desc(mean_mpg))

print(result)`
  },
  {
    name: 'R - ggplot2 Visualisation',
    desc: 'Scatter plot with a smoothed regression line and clean theme.',
    lang: 'r',
    tags: ['r', 'ggplot2', 'plot', 'visualisation', 'chart', 'tidyverse'],
    code: `library(ggplot2)

# Scatter plot: engine displacement vs fuel efficiency
ggplot(mpg, aes(x = displ, y = hwy, colour = class)) +
  geom_point(alpha = 0.7, size = 2.5) +
  geom_smooth(method = "loess", se = TRUE,
              colour = "grey40", linewidth = 0.8) +
  scale_colour_viridis_d(option = "plasma", end = 0.85) +
  labs(
    title    = "Highway MPG vs Engine Displacement",
    subtitle = "LOESS smoother with 95% confidence band",
    x        = "Displacement (litres)",
    y        = "Highway MPG",
    colour   = "Vehicle class"
  ) +
  theme_minimal(base_size = 13) +
  theme(legend.position = "bottom")`
  },
  {
    name: 'R - Linear Regression & Summary',
    desc: 'Fit an OLS model, inspect coefficients, and check assumptions.',
    lang: 'r',
    tags: ['r', 'regression', 'lm', 'statistics', 'model', 'ols'],
    code: `# Ordinary Least Squares regression
model <- lm(mpg ~ wt + hp + cyl, data = mtcars)

# Coefficient table with 95% CIs
summary(model)
confint(model, level = 0.95)

# Diagnostic plots (residuals, Q-Q, leverage)
par(mfrow = c(2, 2))
plot(model)

# Extract key stats
cat("R-squared :", round(summary(model)$r.squared, 4), "\\n")
cat("Adj R-sq  :", round(summary(model)$adj.r.squared, 4), "\\n")
cat("RMSE      :", round(sqrt(mean(residuals(model)^2)), 4), "\\n")`
  },
  {
    name: 'Bash - Directory Archive Script',
    desc: 'Shell script to dynamically compress and back up folders.',
    lang: 'bash',
    tags: ['bash', 'sh', 'shell', 'backup', 'archive'],
    code: `#!/bin/bash
# Automate workspace compression backups
SOURCE_DIR="./snippet-editor"
BACKUP_DIR="./backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
ARCHIVE_NAME="editor_backup_\${TIMESTAMP}.tar.gz"

mkdir -p "$BACKUP_DIR"
tar -czf "\${BACKUP_DIR}/\${ARCHIVE_NAME}" "$SOURCE_DIR"

echo "Backup transaction completed successfully."
echo "Created archive: \${BACKUP_DIR}/\${ARCHIVE_NAME}"`
  }
];

// --- SELECTORS ---
const editor           = document.getElementById('editor');
const documentTitle    = document.getElementById('document-title');
const focusBtn         = document.getElementById('focus-btn');
const exitFocusBtn     = document.getElementById('exit-focus-btn');
const exportDropdownBtn= document.getElementById('export-dropdown-btn');
const exportMenu       = document.getElementById('export-menu');
const fileSaveBtn      = document.getElementById('file-save');
const fileSaveAsBtn    = document.getElementById('file-save-as');
const fileOpenBtn      = document.getElementById('file-open');
const fileSettingsBtn  = document.getElementById('file-settings');

const themeBtns = {
  light:    document.getElementById('theme-light'),
  midnight: document.getElementById('theme-midnight')
};

const formatBlockSelect    = document.getElementById('format-block');
const toolbarInsertSnippet = document.getElementById('toolbar-insert-snippet');

// Snippet modal
const snippetModal      = document.getElementById('snippet-modal');
const paletteSearch     = document.getElementById('palette-search');
const paletteResults    = document.getElementById('palette-results');
const palettePreview    = document.getElementById('palette-preview');
const palettePreviewCode= document.getElementById('palette-preview-code');

// Footer stats
const statWords   = document.getElementById('stat-words');
const statChars   = document.getElementById('stat-chars');
const statReading = document.getElementById('stat-reading');

// Settings modal (autosave only)
const settingsModal  = document.getElementById('settings-modal');
const settingsClose  = document.getElementById('settings-close');
const settingsAutosave = document.getElementById('settings-autosave');

// --- INIT ---
document.addEventListener('DOMContentLoaded', () => {
  loadSettings();
  applySettings();
  initTabs();
  setupEditor();
  setupToolbar();
  setupThemeSystem();
  setupDropdownMenus();
  setupSnippetPalette();
  setupFileActions();
  setupSettings();
  setupExports();
  setupColorPickers();
  setupTableControls();
  setupSearch();
  setupImagePaste();
  updateStats();
  setupAutosave();
  bindEmbeddedCopyButtons();
  highlightAllCodeBlocks();
  bindAllCodeBlocks();
  bindAllTables();
  bindAllImages();
  setupPageGuides();

  document.getElementById('tab-new-btn').addEventListener('click', newTab);
});

// ─────────────────────────────────────────────
// TAB SYSTEM
// ─────────────────────────────────────────────
function initTabs() {
  tabs.push({
    id: 1,
    title: documentTitle.value || 'Untitled Draft',
    html: editor.innerHTML,
    isDirty: false,
    filePath: null
  });
  renderTabs();
}

function newTab() {
  saveActiveTabState();
  const id = nextTabId++;
  tabs.push({ id, title: 'Untitled Draft', html: '<p><br></p>', isDirty: false, filePath: null });
  switchToTab(id, false);
}

function closeTab(id) {
  if (tabs.length <= 1) return;
  const idx = tabs.findIndex(t => t.id === id);
  if (idx === -1) return;

  if (id === activeTabId) {
    const adjacent = tabs[idx > 0 ? idx - 1 : idx + 1];
    if (adjacent) switchToTab(adjacent.id, false);
  }
  tabs.splice(tabs.findIndex(t => t.id === id), 1);
  renderTabs();
}

function saveActiveTabState() {
  const tab = tabs.find(t => t.id === activeTabId);
  if (!tab) return;
  tab.title    = documentTitle.value || 'Untitled Draft';
  tab.html     = editor.innerHTML;
  tab.isDirty  = state.isDirty;
  tab.filePath = state.filePath;
}

function switchToTab(id, saveFirst = true) {
  if (saveFirst) saveActiveTabState();
  activeTabId = id;
  const tab = tabs.find(t => t.id === id);
  if (!tab) return;

  documentTitle.value = tab.title;
  editor.innerHTML    = tab.html;
  state.isDirty       = tab.isDirty;
  state.filePath      = tab.filePath || null;

  // data-kb-bound / data-hl-bound survive innerHTML serialisation, so clear
  // them now so bindAllCodeBlocks() can re-attach live event listeners.
  editor.querySelectorAll('[data-kb-bound]').forEach(el => delete el.dataset.kbBound);
  editor.querySelectorAll('[data-hl-bound]').forEach(el => delete el.dataset.hlBound);

  renderTabs();
  highlightAllCodeBlocks();
  bindEmbeddedCopyButtons();
  bindAllCodeBlocks();
  bindAllTables();
  bindAllImages();
  updateStats();
  updateWindowTitle();
  updatePageGuides();
  editor.focus();
}

function renderTabs() {
  const scroll = document.getElementById('tabs-scroll');
  if (!scroll) return;
  scroll.innerHTML = '';

  tabs.forEach(tab => {
    const el = document.createElement('div');
    el.className = `tab${tab.id === activeTabId ? ' active' : ''}`;
    el.dataset.tabId = String(tab.id);

    el.innerHTML = `
      ${tab.isDirty ? '<span class="tab-dirty"></span>' : ''}
      <span class="tab-title">${escapeHTML(tab.title)}</span>
      <button class="tab-close" title="Close tab" aria-label="Close tab">
        <svg viewBox="0 0 10 10" width="9" height="9" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
          <line x1="1" y1="1" x2="9" y2="9"/><line x1="9" y1="1" x2="1" y2="9"/>
        </svg>
      </button>`;

    el.addEventListener('click', e => {
      if (e.target.closest('.tab-close')) return;
      if (tab.id !== activeTabId) switchToTab(tab.id);
    });

    el.querySelector('.tab-close').addEventListener('click', e => {
      e.stopPropagation();
      closeTab(tab.id);
    });

    scroll.appendChild(el);
  });

  // Scroll active tab into view
  const active = scroll.querySelector('.tab.active');
  if (active) active.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

// ─────────────────────────────────────────────
// EDITOR CORE
// ─────────────────────────────────────────────
function setupEditor() {
  editor.addEventListener('mouseup', () => { saveSelection(); updateToolbarButtonActiveStates(); });
  editor.addEventListener('keyup', () => { saveSelection(); updateStats(); updateToolbarButtonActiveStates(); });

  editor.addEventListener('keydown', e => {
    if (e.key === 'Tab') {
      e.preventDefault();
      if (e.shiftKey) openSnippetPalette();
      else insertTabSpaces();
    }
  });

  editor.addEventListener('input', () => { markDirty(); updateStats(); });

  documentTitle.addEventListener('input', () => {
    markDirty();
    updateWindowTitle();
    const tab = tabs.find(t => t.id === activeTabId);
    if (tab) {
      tab.title = documentTitle.value || 'Untitled Draft';
      // Live-update just the active tab label, no full re-render
      const activeLabel = document.querySelector(`.tab[data-tab-id="${activeTabId}"] .tab-title`);
      if (activeLabel) activeLabel.textContent = tab.title;
    }
  });
}

function saveSelection() {
  const sel = window.getSelection();
  if (sel.rangeCount > 0) {
    const r = sel.getRangeAt(0);
    if (editor.contains(r.commonAncestorContainer)) state.savedRange = r.cloneRange();
  }
}

function restoreSelection() {
  if (state.savedRange) {
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(state.savedRange);
  }
}

function insertTabSpaces() {
  const spaces = "    ";
  if (state.savedRange) {
    restoreSelection();
    const r = state.savedRange;
    r.deleteContents();
    const node = document.createTextNode(spaces);
    r.insertNode(node);
    r.setStartAfter(node);
    r.setEndAfter(node);
    saveSelection();
  } else {
    document.execCommand('insertText', false, spaces);
  }
}

// ─────────────────────────────────────────────
// TOOLBAR
// ─────────────────────────────────────────────

// Actual CSS font stacks for each named family.
// We write these directly into the CSS variable instead of using nested
// var() references, which WebKit does not resolve reliably from JS.
const FONT_STACKS = {
  // ── Serif ────────────────────────────────────────────────────────────────
  serif:    'Georgia, "Times New Roman", serif',
  palatino: '"Palatino Linotype", Palatino, "Book Antiqua", serif',
  times:    '"Times New Roman", Times, serif',
  charter:  'Charter, "Bitstream Charter", "Sitka Text", Cambria, serif',
  // ── Sans-serif ───────────────────────────────────────────────────────────
  system:   'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  helvetica:'"Helvetica Neue", Helvetica, Arial, sans-serif',
  optima:   'Optima, Candara, "Noto Sans", sans-serif',
  // ── Monospace ────────────────────────────────────────────────────────────
  mono:     'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace',
  courier:  '"Courier New", Courier, monospace'
};

function setupToolbar() {
  // Rich-text format commands
  document.querySelectorAll('.toolbar-btn[data-command]').forEach(btn => {
    btn.addEventListener('mousedown', e => {
      e.preventDefault();
      const cmd = btn.getAttribute('data-command');
      if (cmd === 'formatBlockquote') insertBlockquote();
      else document.execCommand(cmd, false, null);
      if (cmd === 'undo' || cmd === 'redo') markDirty();
      updateToolbarButtonActiveStates();
      updateStats();
      editor.focus();
    });
  });

  formatBlockSelect.addEventListener('change', () => {
    document.execCommand('formatBlock', false, `<${formatBlockSelect.value}>`);
    editor.focus();
    updateStats();
  });

  // ── Font family ──────────────────────────────────────────────────────────
  const toolbarFont = document.getElementById('toolbar-font');
  if (toolbarFont) {
    toolbarFont.value = state.settings.editorFont;

    toolbarFont.addEventListener('change', () => {
      const key   = toolbarFont.value;            // 'serif' | 'system' | 'mono'
      const stack = FONT_STACKS[key] || FONT_STACKS.serif;

      state.settings.editorFont = key;
      persistSettings();

      // If the user has text selected, apply the font to just that selection;
      // otherwise the global CSS-variable change is enough.
      const sel = window.getSelection();
      if (sel && !sel.isCollapsed && editor.contains(sel.anchorNode)) {
        restoreSelection();
        document.execCommand('styleWithCSS', false, true);
        document.execCommand('fontName', false, stack);
        document.execCommand('styleWithCSS', false, false); // restore default
      }

      // Always update the global editor baseline (affects all un-styled text)
      applySettings();
      markDirty();

      // Return focus to editor so typing continues normally
      restoreSelection();
      editor.focus();
    });
  }

  // ── Font size − / + ──────────────────────────────────────────────────────
  const sizeDisplay = document.getElementById('toolbar-font-size-display');
  const decBtn      = document.getElementById('toolbar-font-dec');
  const incBtn      = document.getElementById('toolbar-font-inc');

  const FONT_MIN = 10;
  const FONT_MAX = 72;
  const clampSize = sz => Math.min(FONT_MAX, Math.max(FONT_MIN, Math.round(sz)));

  // Return the computed font-size (px integer) at the current selection start,
  // or fall back to the global editor setting.
  const selectionFontSize = () => {
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      const node = sel.getRangeAt(0).startContainer;
      const el   = node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
      if (el && editor.contains(el)) {
        const px = parseFloat(getComputedStyle(el).fontSize);
        if (px > 0) return Math.round(px);
      }
    }
    return state.settings.fontSize;
  };

  // Apply a size delta (+1 / -1).  When text is selected, reads the
  // selection's *actual* computed size so repeated presses keep incrementing
  // from the current rendered size rather than jumping back to the global value.
  const stepSize = (delta) => {
    restoreSelection();
    const sel     = window.getSelection();
    const hasSel  = sel && sel.rangeCount > 0 && !sel.isCollapsed && editor.contains(sel.anchorNode);
    const base    = hasSel ? selectionFontSize() : state.settings.fontSize;
    const newSize = clampSize(base + delta);
    if (newSize === base && hasSel) return;  // already at limit

    if (hasSel) {
      restoreSelection();
      const range = sel.getRangeAt(0);
      const span  = document.createElement('span');
      span.style.fontSize = `${newSize}px`;
      try {
        // surroundContents wraps in-place — no extract/reinsert, so no
        // whitespace or newline artefacts.  Throws for cross-element ranges.
        range.surroundContents(span);
        const nr = document.createRange();
        nr.selectNodeContents(span);
        sel.removeAllRanges();
        sel.addRange(nr);
      } catch (_) {
        // Complex multi-element selection: only apply the global baseline.
      }
    }

    // Always sync global baseline so new/unstyled text matches
    state.settings.fontSize = newSize;
    persistSettings();
    applySettings();
    if (sizeDisplay) sizeDisplay.textContent = `${newSize}px`;
    markDirty();
    editor.focus();
  };

  if (decBtn) decBtn.addEventListener('mousedown', e => { e.preventDefault(); stepSize(-1); });
  if (incBtn) incBtn.addEventListener('mousedown', e => { e.preventDefault(); stepSize(+1); });
}

// ─────────────────────────────────────────────
// COLOUR PICKERS
// ─────────────────────────────────────────────
const TEXT_COLORS = [
  '#1a202c', '#e53e3e', '#dd6b20', '#d69e2e',
  '#38a169', '#3182ce', '#805ad5', '#d53f8c',
  '#2d3748', '#718096', '#e2e8f0', '#ffffff'
];
const HIGHLIGHT_COLORS = [
  '#fef08a', '#bbf7d0', '#bfdbfe', '#fde68a',
  '#fecaca', '#e9d5ff', '#fbcfe8', '#fed7aa',
  'clear'
];

function setupColorPickers() {
  const textBtn     = document.getElementById('btn-text-color');
  const textPalette = document.getElementById('text-color-palette');
  const textBar     = document.getElementById('text-color-bar');
  const hlBtn       = document.getElementById('btn-highlight-color');
  const hlPalette   = document.getElementById('highlight-color-palette');
  const hlBar       = document.getElementById('highlight-color-bar');
  if (!textBtn || !textPalette || !hlBtn || !hlPalette) return;

  function closePalettes() {
    textPalette.classList.remove('active');
    hlPalette.classList.remove('active');
  }

  // Populate text-colour palette
  TEXT_COLORS.forEach(color => {
    const swatch = document.createElement('button');
    swatch.className = 'color-swatch';
    swatch.style.background = color;
    swatch.title = color;
    swatch.addEventListener('mousedown', e => {
      e.preventDefault(); // preserve selection
      restoreSelection();
      document.execCommand('foreColor', false, color);
      if (textBar) textBar.style.background = color;
      closePalettes();
      editor.focus();
    });
    textPalette.appendChild(swatch);
  });

  // Populate highlight palette
  HIGHLIGHT_COLORS.forEach(color => {
    const swatch = document.createElement('button');
    swatch.className = `color-swatch${color === 'clear' ? ' is-clear' : ''}`;
    if (color !== 'clear') swatch.style.background = color;
    swatch.title = color === 'clear' ? 'Remove highlight' : color;
    swatch.addEventListener('mousedown', e => {
      e.preventDefault();
      restoreSelection();
      if (color === 'clear') {
        // Remove background — try both commands for cross-browser compat
        document.execCommand('hiliteColor', false, 'transparent');
        document.execCommand('backColor',   false, 'transparent');
      } else {
        // hiliteColor wraps only the selection; backColor fills whole block
        document.execCommand('hiliteColor', false, color);
      }
      if (hlBar) hlBar.style.background = color === 'clear' ? '#fef08a' : color;
      closePalettes();
      editor.focus();
    });
    hlPalette.appendChild(swatch);
  });

  // Toggle text-colour palette
  textBtn.addEventListener('mousedown', e => {
    e.preventDefault();
    saveSelection();
    const wasOpen = textPalette.classList.contains('active');
    closePalettes();
    if (!wasOpen) textPalette.classList.add('active');
  });

  // Toggle highlight palette
  hlBtn.addEventListener('mousedown', e => {
    e.preventDefault();
    saveSelection();
    const wasOpen = hlPalette.classList.contains('active');
    closePalettes();
    if (!wasOpen) hlPalette.classList.add('active');
  });

  // Close when clicking outside both pickers
  document.addEventListener('mousedown', e => {
    if (!e.target.closest('.color-btn-wrap')) closePalettes();
  });
}

function updateToolbarButtonActiveStates() {
  document.querySelectorAll('.toolbar-btn[data-command]').forEach(btn => {
    const cmd = btn.getAttribute('data-command');
    if (['removeFormat','formatBlockquote'].includes(cmd)) return;

    if (cmd === 'undo' || cmd === 'redo') {
      // Reflect whether undo/redo is currently possible
      try {
        const enabled = document.queryCommandEnabled(cmd);
        btn.classList.toggle('toolbar-btn-disabled', !enabled);
        btn.disabled = !enabled;
      } catch(e) {}
      return;
    }

    try {
      btn.classList.toggle('active', document.queryCommandState(cmd));
    } catch(e) {}
  });
}

function insertBlockquote() {
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const r = sel.getRangeAt(0);
  const text = r.toString() || "Inspiring quote text...";
  const bq = document.createElement('blockquote');
  bq.innerHTML = `&ldquo;${text}&rdquo;`;
  r.deleteContents();
  r.insertNode(bq);
  const p = document.createElement('p');
  p.innerHTML = '<br>';
  bq.after(p);
  const nr = document.createRange();
  nr.setStart(p, 0);
  nr.collapse(true);
  sel.removeAllRanges();
  sel.addRange(nr);
  saveSelection();
}

// ─────────────────────────────────────────────
// LINE NUMBERS
// ─────────────────────────────────────────────
function createLineNums(pre, codeEl) {
  // Only create once per pre
  if (pre.querySelector('.line-nums')) return pre.querySelector('.line-nums');
  const ln = document.createElement('div');
  ln.className = 'line-nums';
  ln.setAttribute('aria-hidden', 'true');
  pre.insertBefore(ln, codeEl);
  updateLineNums(ln, codeEl);
  return ln;
}

function updateLineNums(ln, codeEl) {
  const lines = (codeEl.textContent || '').split('\n');
  // Always show at least 1 line
  const count = Math.max(1, lines.length);
  ln.innerHTML = Array.from({ length: count }, (_, i) =>
    `<span>${i + 1}</span>`
  ).join('');
}

function refreshCodeLineNums(codeEl) {
  const pre = codeEl && codeEl.closest('pre');
  if (!pre) return;
  const ln = createLineNums(pre, codeEl);
  updateLineNums(ln, codeEl);
}

// ─────────────────────────────────────────────
// SYNTAX HIGHLIGHTING HELPERS
// ─────────────────────────────────────────────
function highlightAllCodeBlocks() {
  document.querySelectorAll('code[class*="language-"]').forEach(el => Prism.highlightElement(el));
}

// Save/restore character offset inside a contenteditable for post-highlight caret position
function getCaretCharOffset(el) {
  const sel = window.getSelection();
  if (!sel.rangeCount) return 0;
  const r = sel.getRangeAt(0).cloneRange();
  r.selectNodeContents(el);
  r.setEnd(sel.getRangeAt(0).endContainer, sel.getRangeAt(0).endOffset);
  return r.toString().length;
}

function setCaretCharOffset(el, offset) {
  const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  let rem = offset;
  let node;
  while ((node = walker.nextNode())) {
    if (rem <= node.textContent.length) {
      const r = document.createRange();
      r.setStart(node, rem);
      r.collapse(true);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
      return;
    }
    rem -= node.textContent.length;
  }
}

// Insert raw text at the current caret position (no block wrapping)
function insertTextAtCaret(text) {
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const r = sel.getRangeAt(0);
  r.deleteContents();
  const node = document.createTextNode(text);
  r.insertNode(node);
  r.setStartAfter(node);
  r.collapse(true);
  sel.removeAllRanges();
  sel.addRange(r);
}

// Bind Enter + Tab handling to a code block so they don't bubble to the
// main editor handler (which would insert block elements instead of \n/spaces)
function bindCodeBlockKeydown(codeEl) {
  if (codeEl.dataset.kbBound) return; // guard against double-binding
  codeEl.dataset.kbBound = '1';
  codeEl.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== 'Tab') return;
    e.preventDefault();
    e.stopPropagation(); // stop the main editor handler from seeing this
    insertTextAtCaret(e.key === 'Tab' ? '    ' : '\n');
    refreshCodeLineNums(codeEl);
    codeEl.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: e.key === 'Tab' ? 'insertText' : 'insertLineBreak',
      data: e.key === 'Tab' ? '    ' : '\n'
    }));
    markDirty();
    updateStats();
  });
}

function bindHighlightListeners(codeEl) {
  if (codeEl.dataset.hlBound) return; // guard against double-binding
  codeEl.dataset.hlBound = '1';

  const reHighlight = debounce(() => {
    // Capture offset before any DOM mutation
    const offset  = getCaretCharOffset(codeEl);
    const rawText = codeEl.textContent;

    // Replace innerHTML via Prism (textContent= then highlightElement)
    codeEl.textContent = rawText;
    Prism.highlightElement(codeEl);

    // Refresh line numbers
    refreshCodeLineNums(codeEl);

    // Restore caret; fall back to end-of-block if offset restore fails
    try {
      if (offset > 0) setCaretCharOffset(codeEl, offset);
      else            placeCaretAtEnd(codeEl);
    } catch(e) {
      placeCaretAtEnd(codeEl);
    }
  }, 650);

  codeEl.addEventListener('input', reHighlight);
}

function placeCaretAtEnd(el) {
  el.focus();
  const sel = window.getSelection();
  const r   = document.createRange();
  r.selectNodeContents(el);
  r.collapse(false);
  sel.removeAllRanges();
  sel.addRange(r);
}

// ─────────────────────────────────────────────
// SNIPPET PALETTE
// ─────────────────────────────────────────────
function setupSnippetPalette() {
  state.filteredSnippets = [...snippetCatalog];
  renderSnippetList();

  toolbarInsertSnippet.addEventListener('click', e => { e.preventDefault(); openSnippetPalette(); });

  paletteSearch.addEventListener('input', e => {
    const q = e.target.value.toLowerCase().trim();
    state.filteredSnippets = q === ''
      ? [...snippetCatalog]
      : snippetCatalog.filter(s =>
          s.name.toLowerCase().includes(q) ||
          s.lang.toLowerCase().includes(q) ||
          s.tags.some(t => t.toLowerCase().includes(q)));
    state.activeSnippetIndex = 0;
    renderSnippetList();
  });

  snippetModal.addEventListener('keydown', e => {
    const items = paletteResults.querySelectorAll('.snippet-item');
    if (!items.length) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); state.activeSnippetIndex = (state.activeSnippetIndex + 1) % items.length; updateActivePaletteItem(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); state.activeSnippetIndex = (state.activeSnippetIndex - 1 + items.length) % items.length; updateActivePaletteItem(); }
    else if (e.key === 'Enter') { e.preventDefault(); injectSelectedSnippet(); }
    else if (e.key === 'Escape') { e.preventDefault(); closeSnippetPalette(); }
  });

  snippetModal.addEventListener('click', e => { if (e.target === snippetModal) closeSnippetPalette(); });
}

function openSnippetPalette() {
  saveSelection();
  snippetModal.classList.add('active');
  paletteSearch.value = '';
  state.filteredSnippets = [...snippetCatalog];
  state.activeSnippetIndex = 0;
  renderSnippetList();
  setTimeout(() => paletteSearch.focus(), 50);
}

function closeSnippetPalette() {
  snippetModal.classList.remove('active');
  restoreSelection();
  editor.focus();
}

function renderSnippetList() {
  paletteResults.innerHTML = '';

  if (!state.filteredSnippets.length) {
    paletteResults.innerHTML = `<div style="padding:1.5rem;text-align:center;color:var(--text-muted);font-size:.85rem;">No templates match. Try 'js', 'python', 'sort', or 'flex'.</div>`;
    palettePreview.classList.remove('visible');
    return;
  }

  state.filteredSnippets.forEach((s, idx) => {
    const item = document.createElement('div');
    item.className = `snippet-item${idx === state.activeSnippetIndex ? ' selected' : ''}`;
    item.innerHTML = `
      <div class="snippet-info">
        <span class="snippet-name">${escapeHTML(s.name)}</span>
        <span class="snippet-desc">${escapeHTML(s.desc)}</span>
      </div>
      <span class="snippet-lang-pill">${escapeHTML(s.lang)}</span>`;
    item.addEventListener('click', () => { state.activeSnippetIndex = idx; updateActivePaletteItem(); injectSelectedSnippet(); });
    item.addEventListener('mouseenter', () => { state.activeSnippetIndex = idx; updateActivePaletteItem(false); });
    paletteResults.appendChild(item);
  });

  updateActivePaletteItem();
}

function updateActivePaletteItem(scroll = true) {
  const items = paletteResults.querySelectorAll('.snippet-item');
  items.forEach((item, idx) => {
    const active = idx === state.activeSnippetIndex;
    item.classList.toggle('selected', active);
    if (active) {
      if (scroll) item.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      const s = state.filteredSnippets[idx];
      if (s) {
        palettePreviewCode.className = `language-${s.lang}`;
        palettePreviewCode.textContent = s.code;
        palettePreview.classList.add('visible');
        Prism.highlightElement(palettePreviewCode);
      }
    }
  });
}

function injectSelectedSnippet() {
  const snippet = state.filteredSnippets[state.activeSnippetIndex];
  if (!snippet) return;

  // Build wrapper
  const wrapper = document.createElement('div');
  wrapper.className = 'code-block-wrapper';
  wrapper.setAttribute('contenteditable', 'false');

  const header = document.createElement('div');
  header.className = 'code-header';

  const langTag = document.createElement('span');
  langTag.className = 'code-lang-tag';
  langTag.textContent = snippet.lang;

  const actions = document.createElement('div');
  actions.className = 'code-actions';

  const copyBtn = document.createElement('button');
  copyBtn.className = 'code-action-btn copy-btn';
  copyBtn.innerHTML = `<svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg> Copy`;
  copyBtn.addEventListener('click', e => { e.stopPropagation(); performCopyCode(wrapper.querySelector('code'), copyBtn); });

  actions.appendChild(copyBtn);
  header.appendChild(langTag);
  header.appendChild(actions);

  const pre  = document.createElement('pre');
  const code = document.createElement('code');
  code.className = `language-${snippet.lang}`;
  code.setAttribute('contenteditable', 'true');
  code.setAttribute('spellcheck', 'false');
  code.setAttribute('data-placeholder', 'Start typing...');
  // Blank on insert — user writes their own code; palette preview shows the template
  code.textContent = '';

  pre.appendChild(code);
  wrapper.appendChild(header);
  wrapper.appendChild(pre);

  snippetModal.classList.remove('active');
  restoreSelection();

  const sel = window.getSelection();
  if (sel.rangeCount > 0) {
    const r = sel.getRangeAt(0);
    r.deleteContents();
    r.insertNode(wrapper);
    const p = document.createElement('p');
    p.innerHTML = '<br>';
    wrapper.after(p);
  } else {
    editor.appendChild(wrapper);
  }

  // Highlight BEFORE focusing — Prism replaces innerHTML which destroys
  // any cursor set beforehand, so we must colour first, then place cursor.
  Prism.highlightElement(code);
  createLineNums(pre, code);
  bindHighlightListeners(code);
  bindCodeBlockKeydown(code);
  placeCursorInsideCodeBlock(code);

  code.addEventListener('input', markDirty);
  markDirty();
  updateStats();
}

function placeCursorInsideCodeBlock(code) {
  code.focus();
  // For empty elements, just focus — setting an explicit range on empty
  // contenteditable causes the cursor to snap to top-left.
  if ((code.textContent || '').length === 0) return;
  const sel = window.getSelection();
  const r   = document.createRange();
  r.selectNodeContents(code);
  r.collapse(false);
  sel.removeAllRanges();
  sel.addRange(r);
  saveSelection();
}

// ─────────────────────────────────────────────
// MARKDOWN IMPORT
// ─────────────────────────────────────────────

/** Escape HTML entities in a raw string */
function _escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

/** Apply inline markdown formatting to an already-HTML-escaped string */
function inlineMd(raw) {
  let s = _escHtml(raw);
  s = s
    .replace(/`([^`]+)`/g,                          '<code>$1</code>')
    .replace(/\*\*\*([^*]+)\*\*\*/g,                '<strong><em>$1</em></strong>')
    .replace(/\*\*([^*\n]+)\*\*/g,                  '<strong>$1</strong>')
    .replace(/__([^_\n]+)__/g,                      '<strong>$1</strong>')
    .replace(/\*([^*\n]+)\*/g,                      '<em>$1</em>')
    .replace(/_([^_\s][^_\n]*)_/g,                  '<em>$1</em>')
    .replace(/~~([^~\n]+)~~/g,                      '<strike>$1</strike>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g,            '<a href="$2">$1</a>');
  return s;
}

/** Build the frank code-block wrapper HTML for a given language + code text */
function mdCodeBlockHTML(lang, codeText) {
  const safeLang = (lang || 'text').replace(/[^a-z0-9+#-]/gi, '') || 'text';
  const safeCode = _escHtml(codeText);
  return (
    `<div class="code-block-wrapper" contenteditable="false">` +
    `<div class="code-header">` +
    `<span class="code-lang-tag">${safeLang}</span>` +
    `<div class="code-actions">` +
    `<button class="code-action-btn copy-btn">` +
    `<svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>` +
    `<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg> Copy` +
    `</button></div></div>` +
    `<pre><code class="language-${safeLang}" contenteditable="true" spellcheck="false"` +
    ` data-placeholder="Start typing...">${safeCode}</code></pre>` +
    `</div>`
  );
}

/**
 * Parse a Markdown string into frank editor HTML.
 * Supports: H1–H3, fenced code blocks, blockquotes, UL, OL,
 *           thematic breaks, and paragraphs with inline formatting.
 */
function markdownToEditorHTML(md) {
  const lines = (md || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  const out   = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // ── Fenced code block (``` lang) ─────────────────────────────────────
    const fenceOpen = line.match(/^```(\S*)\s*$/);
    if (fenceOpen) {
      const lang      = fenceOpen[1] || 'text';
      const codeLines = [];
      i++;
      while (i < lines.length && !lines[i].match(/^```\s*$/)) {
        codeLines.push(lines[i]);
        i++;
      }
      i++; // consume closing ```
      out.push(mdCodeBlockHTML(lang, codeLines.join('\n')));
      continue;
    }

    // ── ATX headings (# ## ###) ───────────────────────────────────────────
    const hMatch = line.match(/^(#{1,3})\s+(.+)$/);
    if (hMatch) {
      const lvl = hMatch[1].length;
      out.push(`<h${lvl}>${inlineMd(hMatch[2].trim())}</h${lvl}>`);
      i++; continue;
    }

    // ── Blockquote (> ...) ────────────────────────────────────────────────
    if (line.match(/^>\s?/)) {
      const bqParts = [];
      while (i < lines.length && lines[i].match(/^>\s?/)) {
        bqParts.push(lines[i].replace(/^>\s?/, ''));
        i++;
      }
      out.push(`<blockquote>${inlineMd(bqParts.join(' '))}</blockquote>`);
      continue;
    }

    // ── Unordered list (- * +) ────────────────────────────────────────────
    if (line.match(/^[-*+]\s/)) {
      const items = [];
      while (i < lines.length && lines[i].match(/^[-*+]\s/)) {
        items.push(`<li>${inlineMd(lines[i].replace(/^[-*+]\s/, ''))}</li>`);
        i++;
      }
      out.push(`<ul>${items.join('')}</ul>`);
      continue;
    }

    // ── Ordered list (1. 2. …) ───────────────────────────────────────────
    if (line.match(/^\d+\.\s/)) {
      const items = [];
      while (i < lines.length && lines[i].match(/^\d+\.\s/)) {
        items.push(`<li>${inlineMd(lines[i].replace(/^\d+\.\s/, ''))}</li>`);
        i++;
      }
      out.push(`<ol>${items.join('')}</ol>`);
      continue;
    }

    // ── Thematic break (--- *** ___) ─────────────────────────────────────
    if (line.match(/^[-*_]{3,}\s*$/)) {
      out.push('<hr>'); i++; continue;
    }

    // ── Blank line ────────────────────────────────────────────────────────
    if (line.trim() === '') { i++; continue; }

    // ── Paragraph (soft-wrap continuation lines) ──────────────────────────
    const paraLines = [line];
    i++;
    while (
      i < lines.length &&
      lines[i].trim() !== '' &&
      !lines[i].match(/^(#{1,3}\s|```|[-*+]\s|\d+\.\s|>\s?|[-*_]{3,}\s*$)/)
    ) {
      paraLines.push(lines[i]);
      i++;
    }
    out.push(`<p>${inlineMd(paraLines.join(' '))}</p>`);
  }

  return out.length ? out.join('') : '<p><br></p>';
}

/**
 * Load a Markdown string into the active tab.
 * Derives the document title from the first H1 (or the filename).
 */
function loadMarkdownDocument(md, filePath = null) {
  const h1 = md.match(/^#\s+(.+)/m);
  const title = h1
    ? h1[1].trim()
    : (filePath ? filePath.split('/').pop().replace(/\.md$/i, '') : 'Imported');

  documentTitle.value = title;
  editor.innerHTML    = markdownToEditorHTML(md);
  state.filePath      = filePath;
  state.isDirty       = false;

  // Clear serialised binding guards so listeners re-attach cleanly
  editor.querySelectorAll('[data-kb-bound]').forEach(el => delete el.dataset.kbBound);
  editor.querySelectorAll('[data-hl-bound]').forEach(el => delete el.dataset.hlBound);

  highlightAllCodeBlocks();
  bindEmbeddedCopyButtons();
  bindAllCodeBlocks();
  bindAllTables();
  bindAllImages();
  updateStats();
  updateWindowTitle();
  updatePageGuides();
  setSaveStatus('Markdown imported');

  const tab = tabs.find(t => t.id === activeTabId);
  if (tab) {
    tab.title    = title;
    tab.html     = editor.innerHTML;
    tab.isDirty  = false;
    tab.filePath = filePath;
    renderTabs();
  }
}

// ─────────────────────────────────────────────
// CLIPBOARD
// ─────────────────────────────────────────────
function performCopyCode(codeNode, btn) {
  if (!codeNode) return;
  navigator.clipboard.writeText(codeNode.textContent).then(() => {
    const orig = btn.innerHTML;
    btn.innerHTML = `<svg viewBox="0 0 24 24" style="stroke:#10b981"><polyline points="20 6 9 17 4 12"></polyline></svg><span style="color:#10b981">Copied!</span>`;
    setTimeout(() => { btn.innerHTML = orig; }, 1800);
  }).catch(() => {
    const ta = document.createElement('textarea');
    ta.value = codeNode.textContent;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    btn.textContent = "Copied!";
    setTimeout(() => { btn.textContent = "Copy"; }, 1500);
  });
}

function bindEmbeddedCopyButtons() {
  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const wrapper = btn.closest('.code-block-wrapper');
      if (wrapper) performCopyCode(wrapper.querySelector('code'), btn);
    });
  });
}

// Bind Enter/Tab + highlight listeners to every code block in the document.
// Safe to call multiple times — guards against double-binding via data attribute.
function bindAllCodeBlocks() {
  document.querySelectorAll('.code-block-wrapper code[contenteditable]').forEach(codeEl => {
    bindCodeBlockKeydown(codeEl);
    bindHighlightListeners(codeEl);
    // Ensure line numbers exist for this block
    const pre = codeEl.closest('pre');
    if (pre) createLineNums(pre, codeEl);
  });
}

// ─────────────────────────────────────────────
// STATS
// ─────────────────────────────────────────────
function updateStats() {
  const clone = editor.cloneNode(true);
  // Strip non-content nodes before counting
  clone.querySelectorAll('.line-nums, .frank-img-caption, .frank-img-resize-handle, .code-actions').forEach(el => el.remove());
  // Unwrap search highlights so text isn't double-counted
  clone.querySelectorAll('mark.frank-hit').forEach(m => m.replaceWith(document.createTextNode(m.textContent)));
  const text  = clone.textContent || "";
  const clean = text.replace(/[\s]+/g, ' ').trim();
  const words = clean === '' ? 0 : clean.split(' ').length;
  statWords.textContent   = `Words: ${words}`;
  statChars.textContent   = `Characters: ${text.length}`;
  statReading.textContent = `Reading Time: ${Math.max(1, Math.ceil(words / 200))} min`;
}

// ─────────────────────────────────────────────
// PAGE BREAK GUIDES
// ─────────────────────────────────────────────
// Approximate content height of one US-Letter page at 96 dpi with 54px top/bottom margins.
// This is a visual guide only — the native PDF bridge renders at actual page dimensions.
const PAGE_GUIDE_H = 960;

const _updatePageGuides = debounce(() => {
  if (state.isFocusMode) {
    const ol = document.getElementById('page-guides-overlay');
    if (ol) ol.innerHTML = '';
    return;
  }

  const workspace = document.querySelector('.editor-workspace');
  const paper     = document.querySelector('.paper');
  if (!workspace || !paper) return;

  // The workspace must be the positioning parent
  workspace.style.position = 'relative';

  let overlay = document.getElementById('page-guides-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'page-guides-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    workspace.appendChild(overlay);
  }

  const top    = paper.offsetTop;
  const left   = paper.offsetLeft;
  const width  = paper.offsetWidth;
  const height = paper.offsetHeight;

  overlay.style.cssText =
    `position:absolute;top:${top}px;left:${left}px;` +
    `width:${width}px;height:${height}px;` +
    `pointer-events:none;z-index:2;overflow:hidden;`;

  let html = '';
  for (let y = PAGE_GUIDE_H; y < height; y += PAGE_GUIDE_H) {
    const page = Math.floor(y / PAGE_GUIDE_H) + 1;
    html += `<div class="pgb" style="top:${y}px">` +
            `<span class="pgb-label">page&nbsp;${page}</span></div>`;
  }
  overlay.innerHTML = html;
}, 200);

function updatePageGuides() { _updatePageGuides(); }

function setupPageGuides() {
  updatePageGuides();
  window.addEventListener('resize', updatePageGuides);
  editor.addEventListener('input', updatePageGuides);
}

// ─────────────────────────────────────────────
// THEME
// ─────────────────────────────────────────────
function setupThemeSystem() {
  Object.keys(themeBtns).forEach(theme => {
    themeBtns[theme].addEventListener('click', () => {
      document.documentElement.setAttribute('data-theme', theme);
      state.activeTheme = theme;
      Object.keys(themeBtns).forEach(t => themeBtns[t].classList.remove('active'));
      themeBtns[theme].classList.add('active');
    });
  });
  focusBtn.addEventListener('click', () => toggleFocusMode(true));
  exitFocusBtn.addEventListener('click', () => toggleFocusMode(false));
}

function toggleFocusMode(enable) {
  state.isFocusMode = enable;
  document.body.classList.toggle('focus-mode', enable);
  updatePageGuides();
}

// ─────────────────────────────────────────────
// DROPDOWNS
// ─────────────────────────────────────────────
function setupDropdownMenus() {
  exportDropdownBtn.addEventListener('click', e => { e.stopPropagation(); exportMenu.classList.toggle('active'); });
  document.addEventListener('click', () => exportMenu.classList.remove('active'));
}

// ─────────────────────────────────────────────
// FILE ACTIONS
// ─────────────────────────────────────────────
function setupFileActions() {
  fileSaveBtn.addEventListener('click', saveDocument);
  fileSaveAsBtn.addEventListener('click', saveDocumentAs);
  fileOpenBtn.addEventListener('click', openDocument);
  fileSettingsBtn.addEventListener('click', openSettings);

  document.addEventListener('keydown', e => {
    if (!(e.metaKey || e.ctrlKey)) return;
    const k = e.key.toLowerCase();

    if (k === 's') { e.preventDefault(); e.shiftKey ? saveDocumentAs() : saveDocument(); }
    else if (k === 'o') { e.preventDefault(); openDocument(); }
    else if (k === 'f') { e.preventDefault(); openSearch(); }
    else if (k === ',') { e.preventDefault(); openSettings(); }
    else if (k === 't') { e.preventDefault(); newTab(); }
    else if (k === 'w') { e.preventDefault(); closeTab(activeTabId); }

    // Undo / Redo — JS fallback so toolbar state refreshes and markDirty fires
    else if (k === 'z' && !e.shiftKey) {
      // Let the native Edit menu / WKWebView handle the actual undo;
      // we only update toolbar state afterwards.
      requestAnimationFrame(updateToolbarButtonActiveStates);
    }
    else if ((k === 'z' && e.shiftKey) || k === 'y') {
      requestAnimationFrame(updateToolbarButtonActiveStates);
    }
  });

  window.frankNativeDidSave = (result) => {
    if (result && result.path) state.filePath = result.path;
    state.isDirty = false;
    updateWindowTitle();
    setSaveStatus(result && result.autosave ? 'Autosaved' : 'Saved');
    const tab = tabs.find(t => t.id === activeTabId);
    if (tab) { tab.isDirty = false; tab.filePath = state.filePath; renderTabs(); }
  };

  window.frankNativeDidOpen = (result) => {
    if (!result || !result.content) return;
    const ext = (result.type || '').toLowerCase();
    if (ext === 'md' || ext === 'markdown') {
      loadMarkdownDocument(result.content, result.path || null);
    } else {
      loadFrankDocument(result.content, result.path || null);
    }
  };

  window.frankNativeDidFail = (msg) => { if (msg) setSaveStatus(msg); };
  window.frankNativeDidExport = (r) => { setSaveStatus(r && r.kind ? `${r.kind} exported` : 'Exported'); };
}

function setupExports() {
  document.getElementById('export-md').addEventListener('click', exportToMarkdown);
  document.getElementById('export-doc').addEventListener('click', exportToWord);
  document.getElementById('export-pdf').addEventListener('click', exportToPDF);
  const importMdBtn = document.getElementById('import-md');
  if (importMdBtn) importMdBtn.addEventListener('click', openDocument);
}

function saveDocument() {
  const content  = serializeFrankDocument();
  const filename = `${safeDocumentTitle()}.fm`;
  if (nativePost({ action: 'saveFM', filename, content, path: state.filePath || '' })) return;
  localStorage.setItem('frank:lastDocument', content);
  state.isDirty = false;
  updateWindowTitle();
  setSaveStatus('Saved locally');
  const tab = tabs.find(t => t.id === activeTabId);
  if (tab) { tab.isDirty = false; renderTabs(); }
}

function saveDocumentAs() {
  const content  = serializeFrankDocument();
  const filename = `${safeDocumentTitle()}.fm`;
  if (nativePost({ action: 'saveAsFM', filename, content })) return;
  triggerFileDownload(content, 'application/json;charset=utf-8', '.fm');
}

function openDocument() {
  const bridge = window.webkit &&
                 window.webkit.messageHandlers &&
                 window.webkit.messageHandlers.openFileHandler;
  if (bridge) {
    bridge.postMessage({});
  } else {
    alert('File opening is available in the macOS app.');
  }
}

function autosaveDocument() {
  if (!state.settings.autosaveEnabled || !state.isDirty) return;
  const content = serializeFrankDocument();
  if (state.filePath && nativePost({ action: 'autosaveFM', filename: `${safeDocumentTitle()}.fm`, content, path: state.filePath })) return;
  localStorage.setItem('frank:autosaveDraft', content);
  setSaveStatus('Draft autosaved');
}

function setupAutosave() {
  if (state.autosaveTimer) { clearInterval(state.autosaveTimer); state.autosaveTimer = null; }
  if (state.settings.autosaveEnabled) state.autosaveTimer = setInterval(autosaveDocument, 5 * 60 * 1000);
}

// ─────────────────────────────────────────────
// SETTINGS (autosave only — font/size in toolbar)
// ─────────────────────────────────────────────
function setupSettings() {
  syncSettingsControls();
  settingsClose.addEventListener('click', closeSettings);
  settingsModal.addEventListener('click', e => { if (e.target === settingsModal) closeSettings(); });
  settingsAutosave.addEventListener('change', () => {
    state.settings.autosaveEnabled = settingsAutosave.checked;
    persistSettings();
    setupAutosave();
  });
}

function openSettings() {
  syncSettingsControls();
  settingsModal.classList.add('active');
}

function closeSettings() {
  settingsModal.classList.remove('active');
  editor.focus();
}

function syncSettingsControls() {
  if (settingsAutosave) settingsAutosave.checked = Boolean(state.settings.autosaveEnabled);
}

function loadSettings() {
  try { state.settings = { ...state.settings, ...JSON.parse(localStorage.getItem('frank:settings') || '{}') }; } catch(e) {}
}

function persistSettings() {
  localStorage.setItem('frank:settings', JSON.stringify(state.settings));
}

function applySettings() {
  // Write the real font stack directly — nested var() references set from JS
  // are not reliably resolved by WebKit, so we avoid them entirely.
  const stack = FONT_STACKS[state.settings.editorFont] || FONT_STACKS.serif;
  document.documentElement.style.setProperty('--active-editor-font', stack);
  document.documentElement.style.setProperty('--active-editor-size', `${state.settings.fontSize}px`);

  // Sync toolbar controls to current state
  const sd = document.getElementById('toolbar-font-size-display');
  if (sd) sd.textContent = `${state.settings.fontSize}px`;
  const tf = document.getElementById('toolbar-font');
  if (tf) tf.value = state.settings.editorFont;
}

// ─────────────────────────────────────────────
// DIRTY / TITLE STATE
// ─────────────────────────────────────────────
function markDirty() {
  if (!state.isDirty) {
    state.isDirty = true;
    const tab = tabs.find(t => t.id === activeTabId);
    if (tab && !tab.isDirty) { tab.isDirty = true; renderTabs(); }
  }
  updateWindowTitle();
}

function updateWindowTitle() {
  document.title = `${documentTitle.value || 'Untitled Draft'}${state.isDirty ? ' *' : ''} - frank`;
}

function setSaveStatus(label) {
  if (statReading) statReading.textContent = `${label} — ${new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}`;
}

function safeDocumentTitle() {
  return (documentTitle.value.trim() || 'untitled_draft').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'') || 'untitled_draft';
}

// ─────────────────────────────────────────────
// DOCUMENT SERIALIZATION
// ─────────────────────────────────────────────
function buildFrankDocument() {
  // Clone so search highlights don't end up in saved content
  const clone = editor.cloneNode(true);
  clone.querySelectorAll('mark.frank-hit').forEach(m => m.replaceWith(document.createTextNode(m.textContent)));
  clone.normalize();
  return { format:'frank.fm', version:1, title: documentTitle.value.trim()||'Untitled Draft', html: clone.innerHTML, settings:{...state.settings}, savedAt: new Date().toISOString() };
}

function serializeFrankDocument() { return JSON.stringify(buildFrankDocument(), null, 2); }

const FRANK_ALLOWED_TAGS = new Set([
  'A', 'B', 'BLOCKQUOTE', 'BR', 'CODE', 'DIV', 'EM', 'FIGCAPTION', 'FIGURE',
  'H1', 'H2', 'H3', 'H4', 'HR', 'I', 'IMG', 'LI', 'MARK', 'OL', 'P', 'PRE',
  'S', 'SPAN', 'STRIKE', 'STRONG', 'SUB', 'SUP', 'TABLE', 'TBODY', 'TD',
  'TH', 'THEAD', 'TR', 'U', 'UL'
]);

const FRANK_REMOVE_WITH_CONTENT = new Set([
  'SCRIPT', 'STYLE', 'IFRAME', 'OBJECT', 'EMBED', 'LINK', 'META', 'FORM',
  'INPUT', 'BUTTON', 'TEXTAREA', 'SELECT', 'OPTION', 'SVG', 'MATH', 'CANVAS',
  'VIDEO', 'AUDIO', 'SOURCE'
]);

function frankSafeURL(value, kind) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  const lower = raw.toLowerCase();
  if (kind === 'image') {
    if (lower.startsWith('data:image/') || lower.startsWith('blob:')) return raw;
    return '';
  }
  if (
    lower.startsWith('https://') ||
    lower.startsWith('http://') ||
    lower.startsWith('mailto:') ||
    lower.startsWith('#')
  ) return raw;
  return '';
}

function frankSafeStyle(value) {
  return String(value || '')
    .split(';')
    .map(part => part.trim())
    .filter(Boolean)
    .filter(part => !/url\s*\(|expression\s*\(|javascript:/i.test(part))
    .join('; ');
}

function sanitizeFrankHTML(rawHTML) {
  const template = document.createElement('template');
  template.innerHTML = String(rawHTML || '');
  const nodes = [];
  const walker = document.createTreeWalker(template.content, NodeFilter.SHOW_ELEMENT);
  while (walker.nextNode()) nodes.push(walker.currentNode);

  for (const node of nodes) {
    const tag = node.tagName;
    if (FRANK_REMOVE_WITH_CONTENT.has(tag)) {
      node.remove();
      continue;
    }
    if (!FRANK_ALLOWED_TAGS.has(tag)) {
      node.replaceWith(...Array.from(node.childNodes));
      continue;
    }

    for (const attr of Array.from(node.attributes)) {
      const name = attr.name.toLowerCase();
      const value = attr.value;
      if (name.startsWith('on')) {
        node.removeAttribute(attr.name);
      } else if (name === 'href' && tag === 'A') {
        const safe = frankSafeURL(value, 'link');
        if (safe) {
          node.setAttribute('href', safe);
          node.setAttribute('rel', 'noopener noreferrer');
        } else {
          node.removeAttribute(attr.name);
        }
      } else if (name === 'src' && tag === 'IMG') {
        const safe = frankSafeURL(value, 'image');
        if (safe) node.setAttribute('src', safe);
        else node.remove();
      } else if (name === 'style') {
        const safe = frankSafeStyle(value);
        if (safe) node.setAttribute('style', safe);
        else node.removeAttribute(attr.name);
      } else if (![
        'alt', 'aria-label', 'class', 'colspan', 'data-lang', 'rowspan', 'spellcheck',
        'title'
      ].includes(name)) {
        node.removeAttribute(attr.name);
      }
    }
  }

  return template.innerHTML || '<p><br></p>';
}

function loadFrankDocument(rawContent, filePath = null) {
  try {
    const doc = JSON.parse(rawContent);
    if (!doc || doc.format !== 'frank.fm') throw new Error('Unsupported frank document format.');
    documentTitle.value = doc.title || 'Untitled Draft';
    editor.innerHTML   = sanitizeFrankHTML(doc.html || '<p><br></p>');
    if (doc.settings) { state.settings = { ...state.settings, ...doc.settings }; persistSettings(); applySettings(); setupAutosave(); }
    state.filePath = filePath;
    state.isDirty  = false;
    bindEmbeddedCopyButtons();
    highlightAllCodeBlocks();
    bindAllCodeBlocks();
    bindAllTables();
    bindAllImages();
    updateStats();
    updateWindowTitle();
    setSaveStatus('Opened');
    const tab = tabs.find(t => t.id === activeTabId);
    if (tab) { tab.title = documentTitle.value; tab.html = editor.innerHTML; tab.isDirty = false; tab.filePath = filePath; renderTabs(); }
  } catch(e) { alert(e.message || 'Could not open this .fm file.'); }
}

// ─────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────
function exportToMarkdown() {
  let md = "";
  Array.from(editor.childNodes).forEach(node => {
    if (node.nodeType === Node.TEXT_NODE) { if (node.textContent.trim()) md += node.textContent + "\n\n"; return; }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const tag = node.tagName.toLowerCase();
    if (tag === 'h1') md += `# ${node.textContent.trim()}\n\n`;
    else if (tag === 'h2') md += `## ${node.textContent.trim()}\n\n`;
    else if (tag === 'h3') md += `### ${node.textContent.trim()}\n\n`;
    else if (tag === 'p') { const h = node.innerHTML; if (h !== '<br>' && h.trim()) md += `${parseInlineStyles(node)}\n\n`; }
    else if (tag === 'blockquote') md += `> ${node.textContent.trim()}\n\n`;
    else if (tag === 'ul') { node.querySelectorAll('li').forEach(li => { md += `- ${parseInlineStyles(li)}\n`; }); md += "\n"; }
    else if (tag === 'ol') { node.querySelectorAll('li').forEach((li,i) => { md += `${i+1}. ${parseInlineStyles(li)}\n`; }); md += "\n"; }
    else if (node.classList.contains('code-block-wrapper')) {
      const lang = (node.querySelector('.code-lang-tag')||{}).textContent || 'code';
      const code = (node.querySelector('code')||{}).textContent || '';
      md += `\`\`\`${lang}\n${code}\n\`\`\`\n\n`;
    }
  });
  triggerFileDownload(md.trim(), 'text/markdown;charset=utf-8', '.md');
}

function parseInlineStyles(el) {
  let t = el.innerHTML;
  t = t.replace(/<strong>(.*?)<\/strong>/gi,'**$1**').replace(/<b>(.*?)<\/b>/gi,'**$1**')
       .replace(/<em>(.*?)<\/em>/gi,'*$1*').replace(/<i>(.*?)<\/i>/gi,'*$1*')
       .replace(/<u>(.*?)<\/u>/gi,'<u>$1</u>').replace(/<strike>(.*?)<\/strike>/gi,'~~$1~~')
       .replace(/<code>(.*?)<\/code>/gi,'`$1`').replace(/<a\s+[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi,'[$2]($1)');
  const span = document.createElement('span');
  span.innerHTML = t;
  return span.textContent;
}

function exportToWord() {
  const title = documentTitle.value || "document";
  const html = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head><meta charset="utf-8"><title>${title}</title>
<style>
body{font-family:Georgia,serif;line-height:1.6;color:#333;margin:1.5in 1.2in}
h1,h2,h3{font-family:Arial,sans-serif;color:#111;margin-top:24pt;margin-bottom:12pt}
h1{font-size:24pt;border-bottom:1px solid #ccc;padding-bottom:6pt}
h2{font-size:18pt}h3{font-size:14pt}
p{margin-bottom:12pt;font-size:11pt}
blockquote{border-left:3pt solid #5a7f50;padding-left:12pt;margin:12pt 0;color:#555;font-style:italic}
ul,ol{margin-bottom:12pt;padding-left:20pt}li{margin-bottom:4pt}
.code-block-wrapper{background:#1e1e2e;border:1px solid #ddd;padding:12pt;margin:18pt 0;border-radius:6px}
.code-header{display:none}pre{background:#1e1e2e;padding:8pt;margin:0}
code{font-family:'Courier New',monospace;font-size:10pt;color:#f8fafc;background:#1e1e2e}
</style></head><body>${editor.innerHTML}</body></html>`;
  triggerFileDownload(html, 'application/msword;charset=utf-8', '.doc');
}

function buildExportHTML() {
  // Deep-clone the editor so we can strip non-content nodes safely
  const clone = editor.cloneNode(true);
  clone.querySelectorAll('.line-nums').forEach(el => el.remove());
  clone.querySelectorAll('.page-break-ruler').forEach(el => el.remove());
  clone.querySelectorAll('.code-actions').forEach(el => el.remove());
  // Strip binding-guard data attributes so the HTML is clean
  clone.querySelectorAll('[data-kb-bound],[data-hl-bound],[data-nav-bound],[data-res-bound],[data-cap-bound]').forEach(el => {
    ['kbBound','hlBound','navBound','resBound','capBound'].forEach(k => delete el.dataset[k]);
  });
  // Unwrap search highlights
  clone.querySelectorAll('mark.frank-hit').forEach(m => m.replaceWith(document.createTextNode(m.textContent)));
  // Normalise images: convert caption input → <figcaption>, remove handle
  clone.querySelectorAll('.frank-figure').forEach(fig => {
    const capInput = fig.querySelector('.frank-img-caption');
    if (capInput) {
      const val = capInput.textContent.trim();
      capInput.remove();
      if (val) {
        const fc = document.createElement('figcaption');
        fc.textContent = val;
        fig.appendChild(fc);
      }
    }
    const handle = fig.querySelector('.frank-img-resize-handle');
    if (handle) handle.remove();
    // Unwrap .frank-img-container while keeping <img>
    const container = fig.querySelector('.frank-img-container');
    if (container) {
      const img = container.querySelector('img');
      if (img) {
        const maxW = container.style.width || '100%';
        img.style.maxWidth = maxW;
        img.style.width    = '100%';
        img.style.height   = 'auto';
        container.replaceWith(img);
      } else {
        container.remove();
      }
    }
    fig.contentEditable = '';
  });

  const bodyHTML = clone.innerHTML;
  const title    = escapeHTML(documentTitle.value || 'Untitled Document');
  const fs       = state.settings.fontSize || 18;

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>${title}</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: Georgia, 'Times New Roman', serif;
    font-size: ${fs}px;
    line-height: 1.75;
    color: #1a202c;
    background: #ffffff;
    padding: 54px 68px;
    max-width: 100%;
  }
  h1, h2, h3, h4 {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
    font-weight: 600;
    color: #111827;
    margin-top: 1.8em;
    margin-bottom: 0.5em;
    line-height: 1.3;
  }
  h1 { font-size: 1.95em; border-bottom: 1.5px solid #e2e8f0; padding-bottom: 0.35em; margin-top: 0; }
  h2 { font-size: 1.45em; }
  h3 { font-size: 1.18em; }
  p  { margin-bottom: 0.9em; }
  ul, ol { margin-bottom: 0.9em; padding-left: 1.6em; }
  li { margin-bottom: 0.25em; }
  blockquote {
    border-left: 4px solid #5a7f50;
    padding: 0.45em 1em;
    margin: 1.2em 0;
    color: #4a5568;
    font-style: italic;
    background: #f7faf7;
    border-radius: 0 5px 5px 0;
  }
  a { color: #2563eb; text-decoration: underline; }
  strong { font-weight: 700; }
  em     { font-style: italic; }

  /* ── Code blocks ─────────────────────────────── */
  .code-block-wrapper {
    background: #1e1e2e;
    border-radius: 8px;
    margin: 1.4em 0;
    overflow: hidden;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  .code-header {
    background: #13131f;
    padding: 0.45em 1em;
    display: flex;
    align-items: center;
  }
  .code-lang-tag {
    font-family: ui-monospace, Menlo, 'Courier New', monospace;
    font-size: 10.5px;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.07em;
  }
  pre {
    display: block !important;
    background: transparent !important;
    margin: 0 !important;
    padding: 0 !important;
    overflow: visible !important;
  }
  .line-nums { display: none !important; }
  code {
    display: block !important;
    font-family: ui-monospace, Menlo, 'Courier New', monospace !important;
    font-size: 12.5px !important;
    line-height: 1.65 !important;
    color: #f1f5f9 !important;
    padding: 0.9em 1.1em !important;
    white-space: pre-wrap !important;
    word-break: break-all !important;
    background: transparent !important;
  }
  /* Syntax token colours matching prism-lite */
  .token.keyword  { color: #c792ea !important; }
  .token.string   { color: #a3e6ac !important; }
  .token.comment  { color: #6272a4 !important; font-style: italic; }
  .token.number   { color: #f78c6c !important; }
  .token.boolean  { color: #ff9cac !important; }
  .token.function { color: #82aaff !important; }

  /* ── Tables ── */
  table { width: 100%; border-collapse: collapse; margin: 1.2em 0; font-size: 0.9em; border: 1px solid #e2e8f0; border-radius: 6px; overflow: hidden; }
  th, td { border: 1px solid #e2e8f0; padding: 0.45em 0.75em; vertical-align: top; }
  thead th { background: #f8fafc; font-weight: 600; font-size: 0.78em; text-transform: uppercase; letter-spacing: 0.05em; color: #64748b; }

  /* ── Images ── */
  figure.frank-figure { display: block; margin: 1.5em auto; text-align: center; page-break-inside: avoid; break-inside: avoid; }
  figure.frank-figure img { display: inline-block; max-width: 100%; height: auto; border-radius: 5px; border: 1px solid #e2e8f0; }
  figure.frank-figure figcaption { display: inline-block; margin-top: 0.4em; background: #fff; color: #3b82f6; border: 1.5px dashed #3b82f6; border-radius: 20px; padding: 0.18em 0.8em; font-size: 0.75em; }

  /* Hide editor-only chrome */
  .page-break-ruler, #page-guides-overlay { display: none !important; }
</style>
</head>
<body>
<h1>${title}</h1>
${bodyHTML}
</body>
</html>`;
}

function exportToPDF() {
  const orig = exportDropdownBtn.innerHTML;
  const exportSVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg>`;

  exportDropdownBtn.innerHTML = `${exportSVG} Generating PDF…`;
  exportMenu.classList.remove('active');

  // Post to native PDFExportBridge (registered as 'pdfExportHandler' in Swift)
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.pdfExportHandler) {
    window.webkit.messageHandlers.pdfExportHandler.postMessage({
      html:     buildExportHTML(),
      filename: `${safeDocumentTitle()}.pdf`
    });
    // The Swift side drives the rest; reset button after a moment
    setTimeout(() => { exportDropdownBtn.innerHTML = orig; }, 2500);
  } else {
    // Fallback for non-native context: download as self-contained HTML
    exportDropdownBtn.innerHTML = orig;
    triggerFileDownload(buildExportHTML(), 'text/html;charset=utf-8', '.html');
  }
}

// ─────────────────────────────────────────────
// NATIVE BRIDGE / DOWNLOAD
// ─────────────────────────────────────────────
function nativePost(payload) {
  const b = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.appBridge;
  if (!b) return false;
  b.postMessage(payload);
  return true;
}

function triggerFileDownload(content, mime, ext) {
  const name = `${safeDocumentTitle()}${ext}`;
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.downloadHandler) {
    window.webkit.messageHandlers.downloadHandler.postMessage({ filename:name, content, mime, isDataURI:false });
    return;
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content], { type: mime }));
  a.download = name;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(a.href);
}

// ─────────────────────────────────────────────
// TABLES
// ─────────────────────────────────────────────

// ── Helpers ──────────────────────────────────
function _tableColCount(table) {
  const firstRow = table.querySelector('tr');
  return firstRow ? firstRow.cells.length : 0;
}
function _tableRowCount(table) {
  return table.querySelectorAll('tr').length;
}

function insertTable(rows = 3, cols = 3) {
  const table = document.createElement('table');
  table.className = 'frank-table';

  const thead = document.createElement('thead');
  const hrow  = document.createElement('tr');
  for (let c = 0; c < cols; c++) {
    const th = document.createElement('th');
    th.contentEditable = 'true';
    th.innerHTML = '<br>';
    hrow.appendChild(th);
  }
  thead.appendChild(hrow);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  for (let r = 0; r < rows - 1; r++) {
    const tr = document.createElement('tr');
    for (let c = 0; c < cols; c++) {
      const td = document.createElement('td');
      td.contentEditable = 'true';
      td.innerHTML = '<br>';
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  }
  table.appendChild(tbody);

  const sel = window.getSelection();
  let inserted = false;
  if (sel && sel.rangeCount > 0) {
    let node = sel.getRangeAt(0).startContainer;
    while (node && node.parentNode !== editor) node = node.parentNode;
    if (node && node.parentNode === editor) { node.after(table); inserted = true; }
  }
  if (!inserted) editor.appendChild(table);

  const p = document.createElement('p');
  p.innerHTML = '<br>';
  table.after(p);

  setupTableNavigation(table);
  const firstCell = table.querySelector('th');
  if (firstCell) { firstCell.focus(); placeCaretAtEnd(firstCell); }

  markDirty();
  updateStats();
  updatePageGuides();
}

function addTableRow(table) {
  const tbody = table.querySelector('tbody');
  if (!tbody) return;
  const cols = _tableColCount(table);
  const tr = document.createElement('tr');
  for (let c = 0; c < cols; c++) {
    const td = document.createElement('td');
    td.contentEditable = 'true';
    td.innerHTML = '<br>';
    tr.appendChild(td);
  }
  tbody.appendChild(tr);
  const first = tr.querySelector('td');
  if (first) { first.focus(); placeCaretAtEnd(first); }
  markDirty();
}

function removeLastTableRow(table) {
  const tbody = table.querySelector('tbody');
  if (!tbody) return;
  const rows = tbody.querySelectorAll('tr');
  if (rows.length === 0) return;
  rows[rows.length - 1].remove();
  markDirty();
}

function addTableColumn(table) {
  table.querySelectorAll('tr').forEach((tr, i) => {
    const cell = i === 0 ? document.createElement('th') : document.createElement('td');
    cell.contentEditable = 'true';
    cell.innerHTML = '<br>';
    tr.appendChild(cell);
  });
  markDirty();
}

function removeLastTableColumn(table) {
  if (_tableColCount(table) <= 1) return;
  table.querySelectorAll('tr').forEach(tr => {
    if (tr.lastElementChild) tr.lastElementChild.remove();
  });
  markDirty();
}

function setTableRows(table, target) {
  let cur = _tableRowCount(table);
  while (cur < target) { addTableRow(table);        cur++; }
  while (cur > target && cur > 1) { removeLastTableRow(table);    cur--; }
}
function setTableCols(table, target) {
  let cur = _tableColCount(table);
  while (cur < target) { addTableColumn(table);     cur++; }
  while (cur > target && cur > 1) { removeLastTableColumn(table); cur--; }
}

function setupTableNavigation(table) {
  if (table.dataset.navBound) return;
  table.dataset.navBound = '1';
  table.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab') return;
    const cell = e.target.closest('td, th');
    if (!cell || !table.contains(cell)) return;
    e.preventDefault();
    const allCells = Array.from(table.querySelectorAll('th, td'));
    const idx = allCells.indexOf(cell);
    if (e.shiftKey) {
      if (idx > 0) { allCells[idx - 1].focus(); placeCaretAtEnd(allCells[idx - 1]); }
    } else {
      if (idx < allCells.length - 1) { allCells[idx + 1].focus(); placeCaretAtEnd(allCells[idx + 1]); }
      else addTableRow(table);
    }
    markDirty();
  });
}

function bindAllTables() {
  editor.querySelectorAll('.frank-table').forEach(t => setupTableNavigation(t));
}

// ── Grid picker + hover overlay ───────────────
function setupTableControls() {
  const tbBtn = document.getElementById('toolbar-insert-table');
  if (!tbBtn) return;

  // ─ Picker ─────────────────────────────────────────────────────────────
  const PICK_ROWS = 6, PICK_COLS = 8;
  const picker = document.createElement('div');
  picker.className = 'frank-tbl-picker';
  picker.innerHTML =
    `<div class="frank-tbl-picker-grid" id="ftpg"></div>` +
    `<div class="frank-tbl-picker-dims" id="ftpd">3 × 3</div>`;
  document.body.appendChild(picker);

  const grid   = picker.querySelector('#ftpg');
  const dimsEl = picker.querySelector('#ftpd');

  grid.style.gridTemplateColumns = `repeat(${PICK_COLS}, 1fr)`;
  for (let r = 1; r <= PICK_ROWS; r++) {
    for (let c = 1; c <= PICK_COLS; c++) {
      const cell = document.createElement('button');
      cell.className = 'frank-tbl-picker-cell';
      cell.dataset.r = r;
      cell.dataset.c = c;
      grid.appendChild(cell);
    }
  }

  let pickR = 3, pickC = 3;
  function hilite(r, c) {
    pickR = r; pickC = c;
    grid.querySelectorAll('.frank-tbl-picker-cell').forEach(el => {
      el.classList.toggle('active', +el.dataset.r <= r && +el.dataset.c <= c);
    });
    dimsEl.textContent = `${r} × ${c}`;
  }
  hilite(3, 3);

  grid.addEventListener('mouseover', e => {
    const el = e.target.closest('.frank-tbl-picker-cell');
    if (el) hilite(+el.dataset.r, +el.dataset.c);
  });
  function openPicker() {
    saveSelection();
    const r = tbBtn.getBoundingClientRect();
    picker.style.left = `${r.left}px`;
    picker.style.top  = `${r.bottom + 6}px`;
    picker.classList.add('visible');
  }
  function closePicker() { picker.classList.remove('visible'); }

  tbBtn.addEventListener('mousedown', e => {
    e.preventDefault();
    picker.classList.contains('visible') ? closePicker() : openPicker();
  });
  document.addEventListener('mousedown', e => {
    // Use .contains() so clicks on the inner <svg>/<path> don't falsely close the picker
    if (!picker.contains(e.target) && !tbBtn.contains(e.target)) closePicker();
  });

  // mousedown (not click) so focus never leaves the editor, selection stays intact
  grid.addEventListener('mousedown', e => {
    const el = e.target.closest('.frank-tbl-picker-cell');
    if (!el) return;
    e.preventDefault();          // keep focus in editor
    closePicker();
    restoreSelection();
    insertTable(+el.dataset.r, +el.dataset.c);
  });

  // ─ Hover overlay ──────────────────────────────────────────────────────
  const ov = document.createElement('div');
  ov.id = 'frank-tbl-ov';
  ov.className = 'frank-tbl-ov';
  document.body.appendChild(ov);

  // Control bar
  const tblBar = document.createElement('div');
  tblBar.className = 'frank-tbl-bar';
  tblBar.innerHTML =
    `<span class="frank-tbl-badge">3 × 3</span>` +
    `<span class="frank-tbl-sep"></span>` +
    `<button class="frank-tbl-ctrl" data-act="add-row">+ Row</button>` +
    `<button class="frank-tbl-ctrl" data-act="add-col">+ Col</button>` +
    `<button class="frank-tbl-ctrl frank-tbl-danger" data-act="del-row">− Row</button>` +
    `<button class="frank-tbl-ctrl frank-tbl-danger" data-act="del-col">− Col</button>`;
  ov.appendChild(tblBar);

  const edgeR = document.createElement('button');
  edgeR.className = 'frank-tbl-edge frank-tbl-edge-r';
  edgeR.title = 'Add column'; edgeR.textContent = '+';
  ov.appendChild(edgeR);

  const edgeB = document.createElement('button');
  edgeB.className = 'frank-tbl-edge frank-tbl-edge-b';
  edgeB.title = 'Add row'; edgeB.textContent = '+';
  ov.appendChild(edgeB);

  let activeTable = null;
  let tblHideTimer = null;

  function positionTblOverlay(table) {
    const r = table.getBoundingClientRect();
    ov.style.position = 'fixed';
    ov.style.left   = `${r.left}px`;
    ov.style.top    = `${r.top}px`;
    ov.style.width  = `${r.width}px`;
    ov.style.height = `${r.height}px`;
    ov.style.zIndex = '400';
    ov.style.pointerEvents = 'none';
    const badge = tblBar.querySelector('.frank-tbl-badge');
    if (badge) badge.textContent = `${_tableRowCount(table)} × ${_tableColCount(table)}`;
  }

  function showTblOverlay(table) {
    clearTimeout(tblHideTimer);
    activeTable = table;
    positionTblOverlay(table);
    ov.style.display = 'block';
  }

  let _dimLocked = false;
  let _dimLockTimer = null;

  function hideTblOverlay() {
    if (_dimLocked) return;          // popup is locked — keep overlay alive
    ov.style.display = 'none';
    activeTable = null;
  }

  function scheduleTblHide() {
    if (_dimLocked) return;
    clearTimeout(tblHideTimer);
    tblHideTimer = setTimeout(hideTblOverlay, 1200);   // 1.2 s — enough time to reach the bar
  }

  function dispatchTblAction(act) {
    if (!activeTable) return;
    if      (act === 'add-row') addTableRow(activeTable);
    else if (act === 'add-col') addTableColumn(activeTable);
    else if (act === 'del-row') removeLastTableRow(activeTable);
    else if (act === 'del-col') removeLastTableColumn(activeTable);
    positionTblOverlay(activeTable);
    updateStats();
  }

  // ─ Dimension popup (badge click) ───────────────────────────────────────
  const dimPopup = document.createElement('div');
  dimPopup.className = 'frank-dim-popup';
  dimPopup.innerHTML =
    `<label class="frank-dim-label">Rows<input  type="number" class="frank-dim-input" id="dim-rows" min="1" max="30" value="3"></label>` +
    `<span class="frank-dim-x">×</span>` +
    `<label class="frank-dim-label">Cols<input  type="number" class="frank-dim-input" id="dim-cols" min="1" max="30" value="3"></label>` +
    `<button class="frank-dim-apply">Apply</button>`;
  dimPopup.style.display = 'none';
  document.body.appendChild(dimPopup);

  const badge = tblBar.querySelector('.frank-tbl-badge');

  function openDimPopup() {
    if (!activeTable) return;
    dimPopup.querySelector('#dim-rows').value = _tableRowCount(activeTable);
    dimPopup.querySelector('#dim-cols').value = _tableColCount(activeTable);
    const br = badge.getBoundingClientRect();
    dimPopup.style.left = `${br.left}px`;
    dimPopup.style.top  = `${br.bottom + 6}px`;
    dimPopup.style.display = 'flex';
    setTimeout(() => dimPopup.querySelector('#dim-rows').select(), 30);
    // Lock open for 5 s — ignore all mouse-away dismissal during this window
    _dimLocked = true;
    clearTimeout(_dimLockTimer);
    _dimLockTimer = setTimeout(() => { _dimLocked = false; }, 5000);
  }
  function closeDimPopup(force = false) {
    if (_dimLocked && !force) return;  // respect 5-second lock unless forced
    _dimLocked = false;
    clearTimeout(_dimLockTimer);
    dimPopup.style.display = 'none';
  }

  // ── Long-press (3 s) to open dimension popup ───────────────────────────
  let _badgeHoldTimer = null;
  const BADGE_HOLD_MS = 3000;

  function _cancelBadgeHold() {
    clearTimeout(_badgeHoldTimer);
    _badgeHoldTimer = null;
    badge.classList.remove('frank-tbl-badge-holding');
  }

  badge.addEventListener('mousedown', e => {
    e.preventDefault();
    e.stopPropagation();
    if (dimPopup.style.display !== 'none') { closeDimPopup(); return; }
    badge.classList.add('frank-tbl-badge-holding');
    _badgeHoldTimer = setTimeout(() => {
      badge.classList.remove('frank-tbl-badge-holding');
      openDimPopup();
    }, BADGE_HOLD_MS);
  });

  // Cancel on mouse release, or when mouse exits the bar entirely (last boundary)
  document.addEventListener('mouseup', _cancelBadgeHold);
  tblBar.addEventListener('mouseleave', _cancelBadgeHold);

  dimPopup.querySelector('.frank-dim-apply').addEventListener('click', () => {
    if (!activeTable) { closeDimPopup(true); return; }
    const tr = Math.max(1, Math.min(30, +dimPopup.querySelector('#dim-rows').value || 1));
    const tc = Math.max(1, Math.min(30, +dimPopup.querySelector('#dim-cols').value || 1));
    setTableRows(activeTable, tr);
    setTableCols(activeTable, tc);
    positionTblOverlay(activeTable);
    updateStats();
    closeDimPopup(true);   // user confirmed — force close immediately
  });
  dimPopup.querySelectorAll('.frank-dim-input').forEach(inp => {
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter')  dimPopup.querySelector('.frank-dim-apply').click();
      if (e.key === 'Escape') closeDimPopup(true);  // explicit dismiss
    });
  });
  document.addEventListener('mousedown', e => {
    if (!dimPopup.contains(e.target) && e.target !== badge) closeDimPopup();
    // ↑ will be a no-op during the 5-second lock; user must wait or press Escape
  });

  // Attach actions and hover-keep-alive to interactive children directly
  tblBar.addEventListener('mousedown', e => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    e.preventDefault();
    dispatchTblAction(b.dataset.act);
  });
  edgeR.addEventListener('mousedown', e => { e.preventDefault(); dispatchTblAction('add-col'); });
  edgeB.addEventListener('mousedown', e => { e.preventDefault(); dispatchTblAction('add-row'); });

  [tblBar, edgeR, edgeB, dimPopup].forEach(el => {
    el.addEventListener('mouseenter', () => clearTimeout(tblHideTimer));
    el.addEventListener('mouseleave', scheduleTblHide);
  });

  // Track table hover via the editor
  editor.addEventListener('mouseover', e => {
    const t = e.target.closest('.frank-table');
    if (t) showTblOverlay(t);
  });
  editor.addEventListener('mouseleave', scheduleTblHide);
  editor.addEventListener('mouseout', e => {
    if (e.target.closest('.frank-table') && !ov.contains(e.relatedTarget) && !dimPopup.contains(e.relatedTarget)) scheduleTblHide();
  });

  // Keep overlay alive while cursor moves within the extended hit zone
  document.addEventListener('mousemove', e => {
    if (ov.style.display === 'none' || !activeTable) return;
    const r = ov.getBoundingClientRect();
    const inZone = e.clientX >= r.left  && e.clientX <= r.right
                && e.clientY >= r.top - 50 && e.clientY <= r.bottom + 20;
    if (inZone) clearTimeout(tblHideTimer);
  });

  // Click outside the table + controls → hide immediately (no timer)
  document.addEventListener('mousedown', e => {
    if (ov.style.display === 'none') return;
    const inTable   = activeTable && activeTable.contains(e.target);
    const inBar     = tblBar.contains(e.target);
    const inEdgeR   = edgeR.contains(e.target);
    const inEdgeB   = edgeB.contains(e.target);
    const inDimPop  = dimPopup.contains(e.target);
    if (!inTable && !inBar && !inEdgeR && !inEdgeB && !inDimPop) {
      clearTimeout(tblHideTimer);
      hideTblOverlay();
    }
  }, true);   // capture phase so it fires before other handlers

  // Reposition on scroll
  const ws = document.querySelector('.editor-workspace');
  if (ws) ws.addEventListener('scroll', () => {
    if (activeTable && ov.style.display !== 'none') positionTblOverlay(activeTable);
  });
}

// ─────────────────────────────────────────────
// FULL-TEXT SEARCH
// ─────────────────────────────────────────────
let _searchMatches   = [];
let _searchCurrentIdx = -1;

function setupSearch() {
  const bar   = document.getElementById('search-bar');
  const input = document.getElementById('search-input');
  const prev  = document.getElementById('search-prev');
  const next  = document.getElementById('search-next');
  const close = document.getElementById('search-close');
  const tbBtn = document.getElementById('toolbar-search');
  if (!bar || !input) return;

  tbBtn && tbBtn.addEventListener('mousedown', e => { e.preventDefault(); openSearch(); });

  input.addEventListener('input', () => searchDocument());

  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      navigateSearch(e.shiftKey ? -1 : +1);
    } else if (e.key === 'Escape') {
      closeSearch();
    }
  });

  prev  && prev.addEventListener('click',  () => navigateSearch(-1));
  next  && next.addEventListener('click',  () => navigateSearch(+1));
  close && close.addEventListener('click', () => closeSearch());
}

function openSearch() {
  const bar   = document.getElementById('search-bar');
  const input = document.getElementById('search-input');
  if (!bar) return;
  bar.classList.add('visible');
  setTimeout(() => { if (input) { input.focus(); input.select(); } }, 40);
}

function closeSearch() {
  const bar   = document.getElementById('search-bar');
  const input = document.getElementById('search-input');
  if (!bar) return;
  bar.classList.remove('visible');
  clearSearchHighlights();
  if (input) input.value = '';
  const count = document.getElementById('search-count');
  if (count) { count.textContent = ''; count.className = 'search-count'; }
  editor.focus();
}

function clearSearchHighlights() {
  // Unwrap every <mark class="frank-hit"> back to a plain text node
  editor.querySelectorAll('mark.frank-hit').forEach(mark => {
    const txt = document.createTextNode(mark.textContent);
    mark.replaceWith(txt);
    txt.parentNode && txt.parentNode.normalize();
  });
  _searchMatches    = [];
  _searchCurrentIdx = -1;
}

const _runSearch = debounce(() => {
  clearSearchHighlights();

  const input  = document.getElementById('search-input');
  const count  = document.getElementById('search-count');
  const query  = (input && input.value) || '';

  if (!query.trim()) {
    if (count) { count.textContent = ''; count.className = 'search-count'; }
    return;
  }

  const queryLow = query.toLowerCase();

  // Collect all text nodes in the editor (excluding gutters and captions)
  const walker = document.createTreeWalker(editor, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const p = node.parentElement;
      if (!p) return NodeFilter.FILTER_REJECT;
      if (p.closest('.line-nums, .frank-img-caption, .frank-img-resize-handle, .code-actions')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });

  const textNodes = [];
  let n;
  while ((n = walker.nextNode())) textNodes.push(n);

  textNodes.forEach(textNode => {
    const text    = textNode.textContent;
    const textLow = text.toLowerCase();
    const frags   = [];
    let last = 0, idx;

    while ((idx = textLow.indexOf(queryLow, last)) !== -1) {
      if (idx > last) frags.push(document.createTextNode(text.slice(last, idx)));
      const mark = document.createElement('mark');
      mark.className = 'frank-hit';
      mark.textContent = text.slice(idx, idx + query.length);
      frags.push(mark);
      _searchMatches.push(mark);
      last = idx + query.length;
    }
    if (!frags.length) return;
    if (last < text.length) frags.push(document.createTextNode(text.slice(last)));

    const parent = textNode.parentNode;
    const ref    = textNode.nextSibling;
    parent.removeChild(textNode);
    frags.forEach(f => parent.insertBefore(f, ref));
  });

  if (count) {
    if (_searchMatches.length === 0) {
      count.textContent = 'No results';
      count.className   = 'search-count no-results';
    } else {
      _searchCurrentIdx = 0;
      _highlightCurrentMatch();
      count.textContent = `1 / ${_searchMatches.length}`;
      count.className   = 'search-count';
    }
  }
}, 180);

function searchDocument() { _runSearch(); }

function navigateSearch(dir) {
  if (!_searchMatches.length) return;
  _searchCurrentIdx = (_searchCurrentIdx + dir + _searchMatches.length) % _searchMatches.length;
  _highlightCurrentMatch();
  const count = document.getElementById('search-count');
  if (count) count.textContent = `${_searchCurrentIdx + 1} / ${_searchMatches.length}`;
}

function _highlightCurrentMatch() {
  _searchMatches.forEach((m, i) => m.classList.toggle('frank-hit-current', i === _searchCurrentIdx));
  const cur = _searchMatches[_searchCurrentIdx];
  if (cur) cur.scrollIntoView({ block: 'center', behavior: 'smooth' });
}

// ─────────────────────────────────────────────
// IMAGE PASTE & RESIZE
// ─────────────────────────────────────────────
function setupImagePaste() {
  editor.addEventListener('paste', (e) => {
    const items = e.clipboardData && e.clipboardData.items;
    if (!items) return;
    for (const item of Array.from(items)) {
      if (item.type.startsWith('image/')) {
        e.preventDefault();
        const file = item.getAsFile();
        if (!file) continue;
        const reader = new FileReader();
        reader.onload = ev => insertImage(ev.target.result);
        reader.readAsDataURL(file);
        return;
      }
    }
  });
}

function insertImage(dataURL) {
  const figure = document.createElement('figure');
  figure.className = 'frank-figure';
  figure.contentEditable = 'false';

  const container = document.createElement('div');
  container.className = 'frank-img-container';
  container.style.width = '400px';

  const img = document.createElement('img');
  img.src       = dataURL;
  img.className = 'frank-img';
  img.draggable = false;
  img.alt       = '';

  // Resize handle — top-right arrow
  const handle = document.createElement('button');
  handle.className = 'frank-img-resize-handle';
  handle.title = 'Drag to resize';
  handle.contentEditable = 'false';
  handle.innerHTML =
    `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">` +
    `<line x1="4" y1="12" x2="12" y2="4"/>` +
    `<polyline points="12,4 12,9"/>` +
    `<polyline points="7,4 12,4"/>` +
    `</svg>`;

  container.appendChild(img);
  container.appendChild(handle);

  // Caption pill — div so it auto-expands with text
  const caption = document.createElement('div');
  caption.className = 'frank-img-caption frank-caption-empty';
  caption.contentEditable = 'true';
  caption.dataset.placeholder = 'Add caption…';

  figure.appendChild(container);
  figure.appendChild(caption);

  // ── Absolute canvas placement ──────────────────────────────────────────
  // The figure sits freely on the paper (position: absolute inside position: relative .paper).
  // Calculate initial position: centred horizontally, near the top of the visible viewport.
  const editorWs = document.querySelector('.editor-workspace');
  const scrollTop = editorWs ? editorWs.scrollTop : 0;
  const initialLeft = Math.max(16, Math.round((editor.offsetWidth - 420) / 2));
  const initialTop  = Math.max(16, scrollTop + 60);
  figure.style.position = 'absolute';
  figure.style.left = `${initialLeft}px`;
  figure.style.top  = `${initialTop}px`;
  figure.style.margin = '0';
  editor.appendChild(figure);

  _makeImgResizable(figure);
  _setupCaption(figure);
  _setupFigureDrag(figure);
  markDirty();
  updatePageGuides();
}

function _makeImgResizable(figure) {
  const container = figure.querySelector('.frank-img-container');
  const handle    = figure.querySelector('.frank-img-resize-handle');
  if (!container || !handle || handle.dataset.resBound) return;
  handle.dataset.resBound = '1';

  let startX, startW;
  handle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    startX = e.clientX;
    startW = container.offsetWidth;

    const onMove = (ev) => {
      const newW = Math.max(80, Math.min(820, startW + ev.clientX - startX));
      container.style.width = `${newW}px`;
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup',   onUp);
      markDirty();
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup',   onUp);
  });
}

function _setupCaption(figure) {
  const caption = figure.querySelector('.frank-img-caption');
  if (!caption || caption.dataset.capBound) return;
  caption.dataset.capBound = '1';

  caption.addEventListener('focus', () => caption.classList.remove('frank-caption-empty'));
  caption.addEventListener('blur',  () => {
    if (caption.textContent.trim() === '') caption.classList.add('frank-caption-empty');
    markDirty();
  });
  caption.addEventListener('input', markDirty);
}

function _setupFigureDrag(figure) {
  if (figure.dataset.dragBound) return;
  figure.dataset.dragBound = '1';

  figure.addEventListener('mousedown', (e) => {
    if (e.target.closest('.frank-img-caption, .frank-img-resize-handle')) return;
    e.preventDefault();

    const startMouseX = e.clientX;
    const startMouseY = e.clientY;
    const startLeft   = parseFloat(figure.style.left) || 0;
    const startTop    = parseFloat(figure.style.top)  || 0;

    // Bring figure to front while dragging
    const prevZ = figure.style.zIndex;
    figure.style.zIndex = '200';
    figure.classList.add('dragging');

    const onMove = (ev) => {
      figure.style.left = `${startLeft + ev.clientX - startMouseX}px`;
      figure.style.top  = `${startTop  + ev.clientY - startMouseY}px`;
    };

    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup',   onUp);
      figure.style.zIndex = prevZ;
      figure.classList.remove('dragging');
      markDirty();
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup',   onUp);
  });
}

// (image controls removed — images are now free-placed on the canvas)

function bindAllImages() {
  editor.querySelectorAll('.frank-figure').forEach(fig => {
    // Ensure absolute placement (in case document was saved before this version)
    if (!fig.style.position || fig.style.position !== 'absolute') {
      fig.style.position = 'absolute';
      if (!fig.style.left) fig.style.left = '60px';
      if (!fig.style.top)  fig.style.top  = '60px';
      fig.style.margin = '0';
    }
    _makeImgResizable(fig);
    _setupCaption(fig);
    _setupFigureDrag(fig);
  });
}

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
function escapeHTML(str) {
  return str.replace(/[&<>'"]/g, t => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[t]||t));
}
